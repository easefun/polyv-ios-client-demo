//
//  FullscreenVideoViewController.h
//  polyvSDK
//
//  Created by seanwong on 8/16/15.
//  Copyright (c) 2015 easefun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Video.h"

@interface FullscreenVideoViewController : UIViewController{
    Video *_video;
}


@property (retain) Video *video;
@end
