//
//  FullscreenVideoViewController.m
//  polyvSDK
//
//  Created by seanwong on 8/16/15.
//  Copyright (c) 2015 easefun. All rights reserved.
//

#import "FullscreenVideoViewController.h"
#import "PLVMoviePlayerController.h"


@interface FullscreenVideoViewController (){
    UIActivityIndicatorView * _indicatorView;

}

@property (nonatomic, strong) PLVMoviePlayerController *videoPlayer;


@end

@implementation FullscreenVideoViewController


@synthesize video=_video;




- (void)viewDidLoad {
    

    
    self.videoPlayer = [[PLVMoviePlayerController alloc]initWithVid:_video.vid];

    //self.videoPlayer.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    //self.videoPlayer.view.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
    

    
    CGAffineTransform transform = CGAffineTransformMakeRotation(M_PI/2);
    [self.videoPlayer.view setTransform:transform];
    
    self.videoPlayer.view.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height);
    self.videoPlayer.view.center = CGPointMake(self.view.bounds.size.width/2, self.view.bounds.size.height/2);
    
    self.videoPlayer.controlStyle = MPMovieControlStyleFullscreen;
    
    //NSLog(@"%f,%f,%f,%f",self.videoPlayer.view.bounds.origin.x,self.videoPlayer.view.bounds.origin.y,self.videoPlayer.view.bounds.size.width,self.videoPlayer.view.bounds.size.height);
    
    [self.view addSubview: self.videoPlayer.view];
    
    
    
    

    [self.videoPlayer prepareToPlay];
    
    
    _indicatorView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.videoPlayer.view.frame.size.width/2-10, self.videoPlayer.view.frame.size.height/2-10, 20, 20)];
    
    [_indicatorView setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhite];
    
    [self.view addSubview:_indicatorView];

    [_indicatorView startAnimating];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(playerLoadStateDidChange:)
                                                 name:MPMoviePlayerLoadStateDidChangeNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:nil];
    [super viewDidLoad];

    
    /*[UIView animateWithDuration:0.3f animations:^{
        [self.view setTransform:CGAffineTransformMakeRotation(M_PI_2)];
    } completion:^(BOOL finished) {
       
    }];*/

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) playerLoadStateDidChange:(NSNotification*)notification
{

    
    if ([self.videoPlayer loadState] != MPMovieLoadStateUnknown) {
        [_indicatorView stopAnimating];
        //[_indicatorView removeFromSuperview];
        // Remove observer
        [self.videoPlayer play];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerLoadStateDidChangeNotification object:nil];
        
        
        // Add movie player as subview
        //[[self view] addSubview:[moviePlayer view]];
        
        
        
        
    }
    
}
- (void) moviePlayBackDidFinish:(NSNotification*)notification
{
    NSLog(@"moviePlayBackDidFinish");
    
    NSDictionary *notificationUserInfo = [notification userInfo];
    NSNumber *resultValue = [notificationUserInfo objectForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey];
    MPMovieFinishReason reason = [resultValue intValue];
    if (reason == MPMovieFinishReasonPlaybackError)
    {
        NSError *mediaPlayerError = [notificationUserInfo objectForKey:@"error"];
        if (mediaPlayerError)
        {
            NSLog(@"playback failed with error description: %@", [mediaPlayerError localizedDescription]);
        }
        else
        {
            NSLog(@"playback failed without any given reason");
        }
    }
    
    // Remove observer
    [[NSNotificationCenter 	defaultCenter]
     removeObserver:self
     name:MPMoviePlayerPlaybackDidFinishNotification
     object:nil];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
