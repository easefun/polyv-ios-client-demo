//
//  PolyvPlayerDemoViewController.h
//  polyvSDK
//
//  Created by seanwong on 7/10/14.
//  Copyright (c) 2014 easefun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DownloadDelegate.h"
@interface PolyvPlayerDemoViewController : UIViewController<DownloadDelegate>

@end
