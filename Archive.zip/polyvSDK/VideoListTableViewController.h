//
//  VideoListTableViewController.h
//  polyvSDK
//
//  Created by seanwong on 8/16/15.
//  Copyright (c) 2015 easefun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoListTableViewController : UITableViewController

@end
